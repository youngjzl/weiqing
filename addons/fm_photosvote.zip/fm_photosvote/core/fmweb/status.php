<?php
/**
 * 女神来了模块定义
 *
 * @author 幻月科技
 * @url http://bbs.fmoons.com/
 */
defined('IN_IA') or exit('Access Denied');
//echo $rid;
		$insert = array(
			'status' => intval($_GPC['status'])
		);

		pdo_update($this->table_reply,$insert,array('rid' => $rid));
		if ($_GPC['status'] == 1) {
			$msg = '开启活动成功！';
		} else {
			$msg = '暂停活动成功！';
		}
		$this->message($msg, referer(), 'success');
