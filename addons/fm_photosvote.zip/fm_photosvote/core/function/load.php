<?php
if (!defined('IN_IA')) {
	exit('Access Denied');
}
require FM_CORE . 'version.php';
require FM_CORE . 'function/core.php';
require FM_CORE . 'function/fm_core_c1.php';
require FM_CORE . 'function/fm_core_c2.php';
require FM_CORE . 'function/function.php';